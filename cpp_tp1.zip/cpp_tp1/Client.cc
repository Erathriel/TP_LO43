#include <iostream>

// Include de l'application
#include "Vecteur.h"


int main(int argc, char **argv)
{
  cout << " LO43 - TP1 - Exo 2" << endl << endl;

  // Test de class vecteur
 
}

