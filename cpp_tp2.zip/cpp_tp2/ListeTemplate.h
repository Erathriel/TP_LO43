
// Classe liste
template <class T> class liste {
      // Champs prives
      private:

      // Forme canonique de Coplien
      public:


      // Ajout de maillons

      // Suppression de maillons
         // suppression de la premiere occurence de T
         // suppression du element d'indice donne
         
      // Suppression
         // supprime la tete de la liste
         // supprime tous les elements de la liste

      // Entrees-sorties
         // Fonction constante qui ne peut pas modifier les champs de la classe

      // Autres methodes et operateurs
      // ...
};