#include <iostream>

// Include de l'application
#include "Liste.h"
#include "Maillon.h"

//#include "ListeTemplate.h"

int main(int argc, char *argv[])
{
  cout << " LO43 - TP2 - Exo 1" << endl << endl;

  // Test de Liste et ListeTemplate
 
}


